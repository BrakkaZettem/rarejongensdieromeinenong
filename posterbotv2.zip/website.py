import json
from flask import Flask, render_template, request, redirect
import json
import os
import threading

app = Flask(__name__)

#request.form['submit']




UPLOAD_FOLDER = 'liloutput'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

@app.route('/upload', methods=['GET', 'POST'])
def upload_files():
    if request.method == 'POST':
        print(request.form['submit'])
        if request.form['submit'] == "Upload":
            # Check if the POST request has file parts
            if 'file' not in request.files:
                return redirect(request.url)

            files = request.files.getlist('file')

            # Iterate over the uploaded files
            for file in files:
                # If the user does not select a file, the browser submits an empty file
                if file.filename == '':
                    continue

                # Check if the file is allowed (for example, only allow .txt files)
                # You can add more file extensions as needed
                if file:
                    filename = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
                    file.save(filename)
            return redirect("/upload")
        elif request.form['submit'] == "UploadAlbum":
            print("cock")
            if 'file' not in request.files:
                return redirect(request.url)

            files = request.files.getlist('file')
            os.makedirs(f"{app.config['UPLOAD_FOLDER']}/{request.form['message']}")

            # Iterate over the uploaded files
            for file in files:
                # If the user does not select a file, the browser submits an empty file
                if file.filename == '':
                    continue
                if file:
                    filename = os.path.join(f"{app.config['UPLOAD_FOLDER']}/{request.form['message']}", file.filename)
                    file.save(filename)
            return redirect("/upload")

        else:
            save_autoposter_data(request.form['upload_every'],request.form['custom_message'],request.form['custom_message_frequency'],request.form['custom_message2'],request.form['custom_message2_frequency'],request.form['channel'])
            print("kkr")

    return render_template('upload.html', file_amount=len(os.listdir('liloutput')))




if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port='80')
